import java.util.ArrayList;
import java.util.Random;

// Choix de repr�sentation des blocs�: tableau de bits.

// Les m�thodes crypte et decrypte marchent, avec une l�g�re erreur pour decrypte qui ajoute un espace en fin de d�cryptage.
// S est le m�me tout le long.


public class DES {


	static int[] tab_decalage = {1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1};
	static int[] perm_initiale = {58,50,42,34,26,18,10,2,60,52,44,36,28,20,12,4,62,54,46,38,30,22,14,6,64,56,48,40,32,24,16,8,
			57,49,41,33,25,17,9,1,59,51,43,35,27,19,11,3,61,53,45,37,29,21,13,5,63,55,47,39,31,23,15,7};
	static int[][] S = 
		{{14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7},{0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8},
				{4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0},{15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13}};
	static int[] E = {32,1,2,3,4,5,4,5,6,7,8,9,8,9,10,11,12,13,12,13,14,15,16,17,16,17,18,19,20,21,20,21,22,23,24,25,24,25,26,27,28,29,28,29,30,31,32,1};

	public int[] masterKey = new int[64];
	public ArrayList<int[]> tab_cles = new ArrayList<int[]>();



	// ------------------------- CONVERSION DE STRING EN BITS -------------------------


	// ------------------------- stringToByte -------------------------
	// conversion d'une cha�ne de caract�re en tableau de bytes

	byte[] stringToByte(String phrase) {
		return phrase.getBytes();
	}

	//------------------------- byteToBit -------------------------
	// conversion d'un tableau de bytes en tableau bits

	int[] byteToBit(byte[] Tbyte) {
		String bit = "";
		String courant = new String();
		int diff;

		for (int Ebyte : Tbyte) {
			// conversion du byte courant en base de 2
			courant = Integer.toString(Ebyte,2);
			// rajout du premier 0 si courant est de longueur inf�rieure � 8
			diff = 8 - courant.length();
			while (diff != 0) {
				courant = "0" + courant;
				diff--;
			}
			// concat�nation du bit courant � la cha�ne d�j� convertie
			bit += courant;
		}

		// conversion du String en tableau de int
		int[] Tbit = new int[bit.length()];
		for (int i = 0 ; i<bit.length() ; i++) {
			Tbit[i] = (Character.getNumericValue(bit.charAt(i)));
		}
		return Tbit;
	}

	//------------------------- stringToBit -------------------------
	// conversion d'une cha�ne de caract�re en tableau de bits

	int[] stringToBit(String phrase) {
		return byteToBit(stringToByte(phrase));
	}



	// ------------------------- CONVERSION DE BITS EN STRING -------------------------



	// ------------------------- bitToByte -------------------------
	// conversion d'un tableau de bits en tableau de bytes

	byte[] bitToByte(int[] Tbit) {
		int courant = 0;
		byte[] Tbyte = new byte[Tbit.length/8];

		// conversion de 8 bits successifs en 1 byte
		for (int i=0 ; i<Tbit.length ; i+=8) {
			for (int j=i ; j<i+8 ; j++) {
				courant += Tbit[j]*Math.pow(2, 7-(j%8));
			}
			Tbyte[i/8] = (byte) courant;
			courant = 0;
		}
		return Tbyte;
	}

	// ------------------------- byteToString -------------------------
	// conversion d'un tableau de bytes en cha�ne de caract�res

	String byteToString(byte[] tab) {
		return new String(tab, java.nio.charset.StandardCharsets.UTF_8);
	}

	// ------------------------- bitToString -------------------------
	// conversion d'un tableau de bits en cha�ne de caract�res

	String bitToString(int[] bits) {
		return byteToString(bitToByte(bits));
	}



	// ------------------------- METHODES SUR LES BLOCS -------------------------



	// ------------------------- bitToBloc64 -------------------------
	// conversion d'un tableau de bits en tableau de blocs de 64 bits

	int[][] bitToBloc64(int[] Tbit) {
		int taille = Tbit.length;
		int Ttaille;

		// d�terminer le nombre de blocs de 64bits g�n�r�s
		if (taille%64 == 0) {
			Ttaille = taille/64;
		}
		else {
			Ttaille = taille/64 + 1;
		}

		int[][] bloc64 = new int[Ttaille][64];

		for (int i=0 ; i<Ttaille ; i++) {
			for (int j = 0 ; j<64 ; j++) {
				if (i*64+j < taille) {
					bloc64[i][j] = Tbit[i*64+j];
				}
				else {
					bloc64[i][j] = 0;
				}
			}
		}

		return bloc64;
	}

	// ------------------------- decalageGauche -------------------------
	// d�calage de cran bits du tableau vers la gauche

	int[] decalageGauche(int[] bloc, int cran){
		int[] decaler = new int[bloc.length];
		int fin = bloc.length-cran;

		for (int i=0 ; i<bloc.length ; i++) {
			// cas g�n�ral
			if (i<fin) {
				decaler[i] = bloc[i+cran];
			}
			// remplissage des derni�res cases
			else {
				decaler[i] = bloc[i-fin];
			}
		}
		return decaler;
	}

	// ------------------------- decoupage -------------------------
	// d�coupage d'un bloc en n sous-blocs

	// NOTE : supposer que le nombre de lignes de blocs est divisible par n

	int[][] decoupage(int[] bloc, int n){
		int SBtaille = bloc.length/n;
		int[][] decouper = new int[n][SBtaille];

		for (int i=0 ; i<bloc.length ; i++) {
			decouper[i/SBtaille][i%SBtaille] = bloc[i];
		}
		return decouper;
	}

	// ------------------------- recollage -------------------------
	// recollage des blocs d'un tableau en un seul bloc

	// NOTE : supposer que tous les blocs utilis�s ont la m�me taille

	int[] recollage(int[][] Tbloc){
		int taille = 0;

		// d�terminer la taille des 2 blocs coll�s
		for (int[] bloc : Tbloc) {
			taille += bloc.length;
		}

		int[] recoller = new int[taille];

		for (int i=0 ; i<Tbloc.length ; i++) {
			for (int j=0 ; j<Tbloc[i].length ; j++) {
				recoller[i*Tbloc[i].length + j] = Tbloc[i][j];
			}
		}
		return recoller;
	}



	// ------------------------- METHODES SUR LES PERMUTATIONS -------------------------



	// ------------------------- permutation -------------------------
	// permutation d'un bloc � l'aide d'un tableau de permutation

	int[] permutation(int[] bloc, int[] tab_permutation){
		int[] permuter = new int[bloc.length];

		for (int i=0 ; i<bloc.length ; i++) {
			permuter[i] = bloc[tab_permutation[i] - 1];
		}
		return permuter;
	}

	// ------------------------- generePermutation -------------------------
	// g�n�ration d'une nouvelle permutation de taille n

	int[] generePermutation(int taille) {
		Random r = new Random();
		int hasard;
		// tableau de tous les indices d�j� utilis�s -> 0 si non utilis�, 1 si utilis� 
		int[] deja = new int[taille];
		int[] perm = new int[taille];

		for (int i=0 ; i<taille ; i++) {
			hasard = r.nextInt(taille);
			// v�rifier si l'indice hasard a d�j� �t� utilis�
			while (deja[hasard] == 1) {
				hasard = r.nextInt(taille);
			}
			perm[i] = hasard + 1;
			deja[hasard] = 1;				
		}

		return perm;
	}

	// ------------------------- invPermutation -------------------------
	// renvoi du bloc ayant subi la permutation inverse � perm

	int[] invPermutation(int[] bloc, int[] perm){
		int[] invPermuter = new int[bloc.length];
		int courant;

		for (int i=0 ; i<perm.length ; i++) {
			courant = perm[i] - 1; // car tab de permutation commence � 1
			invPermuter[courant] = bloc[i];
		}
		return invPermuter;
	}


	// ------------------------- METHODES SUR LES CLES -------------------------



	// ------------------------- genereMasterKey -------------------------
	// g�n�ration de la masterKey

	void genereMasterKey(){
		Random r = new Random();

		for (int i=0 ; i<64 ; i++) {
			masterKey[i] = r.nextInt(2);
		}
	}

	// ------------------------- genereCle -------------------------
	// g�n�ration d'une nouvelle cl� pour la ronde n

	int[] genereCle(int n) {
		int[] cle56 = new int[56];

		// extraire une cl� de 56 bits
		for (int i=0 ; i<cle56.length ; i++) {
			cle56[i] = masterKey[i];
		}

		// permutation
		int[] perm56 = generePermutation(56);
		cle56 = permutation(cle56, perm56);

		// d�coupage en 2 sous-blocs de 28 bits
		int[][] Tsb28 = decoupage(cle56, 2);

		// d�calage des 2 sous-blocs
		for (int[] sb : Tsb28) {
			sb = decalageGauche(sb,tab_decalage[n]);
		}

		// recollage des blocs
		cle56 = recollage(Tsb28);

		// permutation
		perm56 = generePermutation(56);
		cle56 = permutation(cle56, perm56);

		// extraire une cl� de 48 bits
		int[] cle48 = new int[48];
		for (int i=0 ; i<cle48.length ; i++) {
			cle48[i] = cle56[i];
		}
		return cle48;
	}



	// ------------------------- AUTRES METHODES -------------------------



	// ------------------------- xor -------------------------
	// op�rateur logique

	// NOTE : supposer que les tableaux sont de taille identique
	// 1-1 / 0-0 = false
	// 1-0 / 0-1 = true

	int[] xor (int[] tab1, int[] tab2) {
		int[] Txor = new int[tab1.length];
		for (int i=0 ; i<tab1.length ; i++) {
			if (tab1[i] == tab2[i]) {
				Txor[i] = 0;
			}
			else {
				Txor[i] = 1;
			}
		}

		return Txor;
	}

	// ------------------------- fonctionS -------------------------
	// fonction de substitution

	// NOTE : supposer que les blocs sont de taille 6 bits

	int[] fonctionS(int[] bloc) {

		// garder bit0 et bit5 pour les convertir en base 10
		int ligne = bloc[5]*2 + bloc[0];

		// garder les autres bits et les convertir en base 10
		int colonne = (int) (bloc[1]*Math.pow(2, 3) + bloc[2]*Math.pow(2, 2) + bloc[3]*2 + bloc[4]);

		// chercher la valeur correspondante dans S et la convertir en base 2
		int valeur = S[ligne][colonne];
		String valeur2 = Integer.toString(valeur,2);
		int[] Tvaleur = new int[4];
		for (int i=0 ; i<valeur2.length() ; i++) {
			Tvaleur[i] = Character.getNumericValue(valeur2.charAt(i));
		}
		return Tvaleur;
	}

	// ------------------------- fonctionF -------------------------
	//

	// NOTE : supposer qu'on a des blocs de 32 bits

	int[] fonctionF(int[] D, int[] cle) {

		// extension d'un bloc de 32 bits en bloc de 48 bits
		int[] D48 = permutation(D,E);

		// xor entre D48 et la cl�
		D48 = xor(E,cle);

		// D48 d�coup� en 8 blocs de 6 bits
		int[][] D6 = decoupage(D48,8);

		// appliquer la fonctionS
		int[][] valeurS = new int[D6.length][4];
		for (int i=0 ; i<D6.length ; i++) {
			valeurS[i] = fonctionS(D6[i]);
		}

		// recoller les blocs en un bloc de 32 bits
		int[] D32 = recollage(valeurS);	
		return D32;
	}



	// ------------------------- METHODE CRYPTE -------------------------



	int[] crypte(String phrase) {

		// conversion en bits
		int[] bits = stringToBit(phrase);

		// division en blocs de 64
		int[][] bloc64 = bitToBloc64(bits);

		// g�n�ration de la masterKey
		genereMasterKey();

		for (int i =0 ; i<bloc64.length ; i++) {

			// permutation initiale
			bloc64[i] = permutation(bloc64[i],perm_initiale);

			// d�coupage en 2 sous-blocs
			int[][] decouper = decoupage(bloc64[i],2);
			int[] Gn = decouper[0];
			int[] Dn = decouper[1];

			// 16 rondes
			for (int ronde=0 ; ronde<16 ; ronde++) {

				// g�n�ration d'une cl� pour le ronde-�me ronde
				int[] cle48 = genereCle(ronde);
				tab_cles.add(cle48);

				// calcul de Dn+1 et Gn+1
				int[] Dbis = Dn; // copie de Dn avant qu'il ne change
				Dn = xor(Gn, fonctionF(Dn,cle48));
				Gn = Dbis;

			}

			// recollage de Gn et Dn
			int[][] finale = {Gn,Dn};
			bloc64[i] = recollage(finale);

			// permutation inverse de la premi�re
			bloc64[i] = invPermutation(bloc64[i], perm_initiale);

		}

		// recollage de tous les blocs
		int[] crypter = recollage(bloc64);

		return crypter;
	}



	// ------------------------- METHODE DECRYPTE -------------------------



	String decrypte(int[] crypter) {

		// division en blocs de 64 bits
		int[][] bloc64 = bitToBloc64(crypter);

		for (int i=0 ; i<bloc64.length ; i++) {

			// permutation initiale
			bloc64[i] = permutation(bloc64[i], perm_initiale);

			// division en 2 sous-blocs
			int[][] decouper = decoupage(bloc64[i],2);
			int[] Gn = decouper[0];
			int[] Dn = decouper[1];

			// 16 rondes
			for (int ronde=0 ; ronde<16 ; ronde++) {

				// r�cup�ration de la cl� de la ronde-�me ronde
				int[] cle48 = tab_cles.get(i*16 + ronde);

				// calcul de Dn-1 et Gn-1
				int[] Dbis = Dn;
				Dn = xor(Gn, fonctionF(Dn, cle48));
				Gn = Dbis;

			}

			// recollage de Gn et Dn
			int[][] finale = {Gn,Dn};
			bloc64[i] = recollage(finale);

			// permutation inverse de la premi�re
			bloc64[i] = invPermutation(bloc64[i], perm_initiale);

		}

		// recollage de tous les blocs
		int[] recoller = recollage(bloc64);

		// conversion en String
		String decrypter = bitToString(recoller);

		return decrypter;

	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DES des = new DES();

		System.out.print("La phrase est : ");

		String phrase = "Bonjour, comment Java ?";

		System.out.println(phrase);



		System.out.println();
		System.out.println("------------------------- CONVERSION DE STRING EN BITS -------------------------");



		// ------------------------- test stringToByte -------------------------

		System.out.println();
		System.out.println("Test stringToByte :");

		byte[] Pbyte= des.stringToByte(phrase);

		for (int b : Pbyte) {
			System.out.print(b + " ");
		}

		System.out.println();

		// ------------------------- test byteToBit -------------------------

		System.out.println();
		System.out.println("Test byteToBit :");

		int[] Pbit = des.byteToBit(Pbyte);

		for (int b : Pbit) {
			System.out.print(b);
		}

		System.out.println();

		// ------------------------- test stringToBit -------------------------

		System.out.println();
		System.out.println("Test stringToBit :");

		int[] Pbit2 = des.stringToBit(phrase);

		boolean ok1 = true;
		for (int i=0 ; i<Pbit2.length ; i++) {
			if (Pbit[i] != Pbit2[i]){
				ok1 = false;
			}
		}
		System.out.println("-> stringToBit et byteToBit renvoient le m�me r�sultat : " + ok1);

		for (int b : Pbit2) {
			System.out.print(b);
		}

		System.out.println();



		System.out.println();
		System.out.println("------------------------- CONVERSION DE STRING EN BITS -------------------------");



		// ------------------------- test bitToByte -------------------------

		System.out.println();
		System.out.println("Test bitToByte :");

		byte[] Tbyte = des.bitToByte(Pbit);

		boolean ok2 = true;
		for (int i=0 ; i<Tbyte.length ; i++) {
			if (Pbyte[i] != Tbyte[i]){
				ok2 = false;
			}
		}
		System.out.println("-> bitToByte et stringToByte renvoient le m�me r�sultat : " + ok2);

		for (int b : Tbyte) {
			System.out.print(b + " ");
		}

		System.out.println();

		// ------------------------- test byteToString -------------------------

		System.out.println();
		System.out.println("Test byteToString :");

		String phrase2 = des.byteToString(Pbyte);

		System.out.println("-> byteToString et phrase renvoient le m�me r�sultat : " + phrase.equals(phrase2));		

		System.out.println(phrase2);

		// ------------------------- test bitToString -------------------------

		System.out.println();
		System.out.println("Test bitToString :");

		String phrase3 = des.bitToString(Pbit);

		System.out.println("-> bitToString et phrase renvoient le m�me r�sultat : " + phrase.equals(phrase3));		

		System.out.println(phrase3);



		System.out.println();
		System.out.println("------------------------- METHODES SUR LES BLOCS -------------------------");



		// ------------------------- test bitToBloc64 -------------------------

		System.out.println();
		System.out.println("Test bitToBloc64 :");

		int[][] bloc64 = des.bitToBloc64(Pbit);

		for (int i = 0 ; i<bloc64.length ; i++) {
			for (int b :  bloc64[i]) {
				System.out.print(b);
			}
			System.out.println(" <- bloc " + i + " : taille = " + bloc64[i].length);
		}

		// ------------------------- test decalageGauche -------------------------

		System.out.println();
		System.out.println("Test decalageGauche :");

		int[] decaler = des.decalageGauche(bloc64[0],2);

		for (int b : bloc64[0]) {
			System.out.print(b);
		}

		System.out.println(" <- bloc 0 sans d�calage");

		for (int b : decaler) {
			System.out.print(b);
		}

		System.out.println(" <- bloc 0 avec d�calage de 2");

		// ------------------------- test decoupage -------------------------

		System.out.println();
		System.out.println("Test decoupage :");

		int[][] decouper = des.decoupage(bloc64[0],2);

		for (int i=0 ; i<decouper.length ; i++) {
			for (int b : decouper[i]) {
				System.out.print(b);
			}
			System.out.println(" <- bloc 0, sous-bloc " + i + " : taille = " + decouper[i].length);
		}

		// ------------------------- test recollage -------------------------

		System.out.println();
		System.out.println("Test recollage :");

		int[] recoller = des.recollage(decouper);

		boolean ok3 = true;
		for (int i=0 ; i<recoller.length ; i++) {
			if (bloc64[0][i] != recoller[i]){
				ok3 = false;
			}
		}
		System.out.println("-> recollage et bloc 0 renvoient le m�me r�sultat : " + ok3);

		for (int i=0 ; i<recoller.length ; i++) {
			System.out.print(recoller[i]);
		}

		System.out.println( " <- bloc 0 : sous-blocs 0 et 1 recoll�s");



		System.out.println();
		System.out.println("------------------------- METHODES SUR LES PERMUTATIONS -------------------------");



		// ------------------------- test permutation -------------------------

		System.out.println();
		System.out.println("Test permutation :");

		int[] permuter = des.permutation(bloc64[0], perm_initiale);

		for (int b : permuter) {
			System.out.print(b);
		}

		System.out.println();

		// ------------------------- test generePermutation -------------------------

		System.out.println();
		System.out.println("Test generePermutation :");

		int[] perm = des.generePermutation(64);

		System.out.println("-> taille = " + perm.length);

		for (int b : perm) {
			System.out.print(b + " ");
		}

		System.out.println();

		// ------------------------- test invPermutation -------------------------

		System.out.println();
		System.out.println("Test invPermutation :");

		int[] invPermuter = des.invPermutation(permuter, perm_initiale);

		boolean ok4 = true;
		for (int i=0 ; i<invPermuter.length ; i++) {
			if (bloc64[0][i] != invPermuter[i]){
				ok4 = false;
			}
		}
		System.out.println("-> invPermutation et bloc 0 renvoient le m�me r�sultat : " + ok4);

		for (int b : invPermuter) {
			System.out.print(b);
		}

		System.out.println();



		System.out.println();
		System.out.println("------------------------- METHODES SUR LES CLES -------------------------");



		// ------------------------- test genereMasterKey -------------------------

		System.out.println();
		System.out.println("Test genereMasterKey :");

		des.genereMasterKey();

		for (int b : des.masterKey) {
			System.out.print(b);
		}

		System.out.println();

		// ------------------------- test genereCle -------------------------

		System.out.println();
		System.out.println("Test genereCle :");

		int[] cle48 = des.genereCle(2);

		System.out.println("-> taille = " + cle48.length);

		for (int b : cle48) {
			System.out.print(b);
		}

		System.out.println();



		System.out.println();
		System.out.println("------------------------- AUTRES METHODES -------------------------");



		// ------------------------- test xor -------------------------

		System.out.println();
		System.out.println("Test xor :");

		int[] tab1 = {1,0,0,0,1};
		int[] tab2 = {1,1,0,1,0};

		int[] Txor = des.xor(tab1, tab2);
		int[] attendu = {0,1,0,1,1};

		for (int b : tab1) {
			System.out.print(b);
		}
		System.out.println(" <- tab1");

		for (int b : tab2) {
			System.out.print(b);
		}
		System.out.println(" <- tab2");

		boolean ok5 = true;
		for (int i=0 ; i<Txor.length ; i++) {
			if (attendu[i] != Txor[i]) {
				ok5 = false;
			}
		}
		System.out.println(" -> valeur attendue (01011) obtenue : " + ok5);

		System.out.println();

		// ------------------------- test fonctionS -------------------------

		System.out.println();
		System.out.println("Test fonctionS :");

		int[] blocS = {1,1,0,1,1,1};

		for (int b : blocS) {
			System.out.print(b);
		}
		System.out.println(" <- exemple des diapositives");

		int[] Tvaleur2 = des.fonctionS(blocS);
		int[] attendu2 = {1,1,1,0};

		boolean ok6 = true;
		for (int i=0 ; i<Tvaleur2.length ; i++) {
			if (attendu2[i] != Tvaleur2[i]) {
				ok6 = false;
			}
		}
		System.out.println("-> valeur attendue (1110) obtenue : " + ok6);

		System.out.println();

		// ------------------------- test fonctionF -------------------------

		System.out.println();
		System.out.println("Test fonctionF :");

		int[] D = des.decoupage(bloc64[0],2)[0];

		int[] D32 = des.fonctionF(D, cle48);

		System.out.println("-> taille = " + D32.length);

		for (int b : D32) {
			System.out.print(b);
		}

		System.out.println();



		System.out.println();
		System.out.println("------------------------- METHODE CRYPTE -------------------------");



		System.out.println();
		System.out.println("Test crypte :");

		int[] crypter = des.crypte(phrase);

		for (int b : crypter) {
			System.out.print(b);
		}

		System.out.println();



		System.out.println();
		System.out.println("------------------------- METHODE DECRYPTE -------------------------");



		System.out.println();
		System.out.println("Test decrypte :");

		String decrypter = des.decrypte(crypter);		

		System.out.println("-> decrypte et phrase renvoient le m�me r�sultat : " + phrase.equals(decrypter));
		System.out.println("Le false est du � un espace ajout� en fin de phrase, s'expliquant s�rement par la s�rie de 0 � la fin du dernier bloc.");

		System.out.println(decrypter);

	}

}